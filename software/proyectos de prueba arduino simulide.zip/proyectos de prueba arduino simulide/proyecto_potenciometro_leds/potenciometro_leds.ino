const int analogPin = A0;
int value; //variable que almacena la lectura analógica raw
int position; //posicion del potenciometro en tanto por ciento


void setup(){
pinMode(2, OUTPUT);
pinMode(3, OUTPUT);
pinMode(4, OUTPUT);
pinMode(5, OUTPUT);
pinMode(6, OUTPUT);

Serial.begin(9600);

}

void loop(){

value = analogRead(analogPin); // realizar la lectura analógica raw
position = map(value, 0, 500, 0, 100); // convertir a porcentaje

Serial.print("Raw: ");
Serial.print(value);
Serial.print("  Posicion: ");
Serial.print(position);
Serial.println(" %");


	if(position>25){
	
		digitalWrite(2, HIGH);
		if (position>50){
		
			digitalWrite(3, HIGH);
			if (position>75){
					
				digitalWrite(4, HIGH);
				if (position>99){
					
					digitalWrite(5, HIGH);
				}
			}		
		}
	
	}
	
	
	
	delay(1000);

}